import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Task from './components/getTask/Task';
import AddTask from './components/addTask/AddTask';
import EditTask from './components/updateTask/EditTask';
import './App.css';

const App = () => {
  return (
    <div>
      <Routes>
        <Route path="/" element={<Task />} />
        <Route path="/add" element={<AddTask />} />
        <Route path="/edit/:id" element={<EditTask />} />
      </Routes>
    </div>
  );
};

export default App;