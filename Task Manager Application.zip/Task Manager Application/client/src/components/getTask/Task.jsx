import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';

const Task = () => {
  const [tasks, setTasks] = useState([]);

  const deleteTask = async (id) => {
    await axios
      .delete(`http://localhost:7000/api/delete/${id}`)
      .then((response) => {
        console.log(response);
        setTasks((prev) => prev.filter((task) => task._id !== id));
        toast.success(response.data.msg);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    const fetchData = async () => {
      const response = await axios.get('http://localhost:7000/api/getAll');
      setTasks(response.data);
    };
    fetchData();
  }, []);

  return (
    <div>
      <div className="m-5 taskTable">
        <h1 className="text-center heading">Task List</h1>
        <Link className="btn btn-success m-3" to="/add">
          Add Task
        </Link>
        <table className="table" border={3} cellPadding={10} cellSpacing={0}>
          <thead>
            <tr>
              <th>S.no</th>
              <th>Title</th>
              <th>Description</th>
              <th>Due Date</th>
              <th>Priority</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((task, index) => {
              return (
                <tr key={task._id}>
                  <td>{index + 1}</td>
                  <td>{task.title}</td>
                  <td>{task.description}</td>
                  <td>{task.dueDate}</td>
                  <td>{task.priority}</td>
                  <td>{task.status}</td>
                  <td>
                    <button
                      onClick={() => {
                        deleteTask(task._id);
                      }}
                      className="btn btn-danger m-3"
                    >
                      <i className="fa-solid fa-trash"></i>
                    </button>
                    <Link
                      className="btn btn-success"
                      to={`/edit/${task._id}`}
                    >
                      <i className="fa-solid fa-pen-to-square"></i>
                    </Link>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Task;