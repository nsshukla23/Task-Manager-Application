import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';

const EditTask = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [task, setTask] = useState({
    title: '',
    description: '',
    dueDate: '',
    priority: '',
    status: '',
  });

  const inputChangeHandler = (e) => {
    const { name, value } = e.target;
    setTask({ ...task, [name]: value });
  };

  const submitForm = async (e) => {
    e.preventDefault();
    await axios
      .put(`http://localhost:7000/api/update/${id}`, task)
      .then((response) => {
        console.log(response);
        toast(response.data.msg);
        navigate('/');
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    axios
      .get(`http://localhost:8000/api/getOne/${id}`)
      .then((response) => {
        console.log(response);
        setTask(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [id]);

  return (
    <div className="updateTask container">
      <h1 className="text-capitalize text-center mt-5 mb-5 heading">
        Update Task
      </h1>
      <form onSubmit={submitForm}>
        <Link className="btn btn-secondary mb-3" to={'/'}>
          Back
        </Link>
        <div className="mb-3">
          <label htmlFor="title" className="form-label">
            Title
          </label>
          <input
            onChange={inputChangeHandler}
            value={task.title}
            className="form-control"
            type="text"
            id="title"
            name="title"
            placeholder="Task title"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="description" className="form-label">
            Description
          </label>
          <textarea
            onChange={inputChangeHandler}
            value={task.description}
            className="form-control"
            type="text"
            id="description"
            name="description"
            placeholder="Task description"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="dueDate" className="form-label">
            Due Date
          </label>
          <input
            onChange={inputChangeHandler}
            value={task.dueDate}
            className="form-control"
            type="date"
            id="dueDate"
            name="dueDate"
            placeholder="Due date"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="priority" className="form-label">
            Priority
          </label>
          <select
            onChange={inputChangeHandler}
            value={task.priority}
            className="form-control"
            id="priority"
            name="priority"
          >
            <option value="">Select Priority</option>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
        <div className="mb-3">
          <label htmlFor="status" className="form-label">
            Status
          </label>
          <select
            onChange={inputChangeHandler}
            value={task.status}
            className="form-control"
            id="status"
            name="status"
          >
            <option value="">Select Status</option>
            <option value="pending">Pending</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
          </select>
        </div>
        <div className="d-flex justify-content-center">
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditTask;