import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';

const AddTask = () => {
  const navigate = useNavigate();
  const [task, setTask] = useState({
    title: '',
    description: '',
    dueDate: '',
    priority: '',
  });

  const inputHandler = (e) => {
    const { name, value } = e.target;
    setTask({ ...task, [name]: value });
  };

  const submitForm = async (e) => {
    e.preventDefault();
    await axios
      .post('http://localhost:7000/api/create', task)
      .then((response) => {
        console.log(response);
        toast(response.data.msg);
        navigate('/');
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="addTask container">
      <h1 className="text-capitalize text-center mt-5 mb-5 heading">
        Add New Task
      </h1>
      <form onSubmit={submitForm}>
        <Link className="btn btn-secondary mb-3" to={'/'}>
          Back
        </Link>
        <div className="mb-3">
          <label htmlFor="title" className="form-label">
            Title
          </label>
          <input
            onChange={inputHandler}
            className="form-control"
            autoComplete="off"
            type="text"
            id="title"
            name="title"
            placeholder="Task title"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="description" className="form-label">
            Description
          </label>
          <textarea
            onChange={inputHandler}
            className="form-control"
            type="text"
            autoComplete="off"
            id="description"
            name="description"
            placeholder="Task description"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="dueDate" className="form-label">
            Due Date
          </label>
          <input
            onChange={inputHandler}
            className="form-control"
            autoComplete="off"
            type="date"
            id="dueDate"
            name="dueDate"
            placeholder="Due date"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="priority" className="form-label">
            Priority
          </label>
          <select
            onChange={inputHandler}
            className="form-control"
            id="priority"
            name="priority"
          >
            <option value="">Select Priority</option>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
        <div className="d-flex justify-content-center">
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddTask;