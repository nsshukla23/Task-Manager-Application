import express from "express";
import {
  createTask,
  deleteTask,
  getAllTasks,
  getTaskById,
  updateTask,
} from "../controller/taskController.js";

const route = express.Router();

route.post("/create", createTask);
route.get("/getAll", getAllTasks);
route.get("/getOne/:id", getTaskById);
route.put("/update/:id", updateTask);
route.delete("/delete/:id", deleteTask);

export default route;