import Task from "../model/taskModel.js";

export const createTask = async (req, res) => {
  try {
    const { title, description, dueDate, priority } = req.body;
    const taskData = new Task({ title, description, dueDate, priority });

    if (!taskData) {
      return res.status(404).json({ msg: "Task data not found" });
    }

    const savedTask = await taskData.save();
    res.status(200).json({ savedTask, msg: "Task created successfully" });
  } catch (error) {
    console.log(error);
  }
};

export const getAllTasks = async (req, res) => {
  try {
    const tasks = await Task.find();
    if (!tasks) {
      return res.status(404).json({ msg: "Tasks not found" });
    }
    res.status(200).json(tasks);
  } catch (error) {
    console.log(error);
  }
};

export const getTaskById = async (req, res) => {
  try {
    const id = req.params.id;
    const task = await Task.findById(id);

    if (!task) {
      return res.status(404).json({ msg: "Task not found" });
    }
    res.status(200).json(task);
  } catch (error) {
    console.log(error);
  }
};

export const updateTask = async (req, res) => {
  try {
    const id = req.params.id;
    const task = await Task.findById(id);

    if (!task) {
      return res.status(404).json({ msg: "Task not found" });
    }
    const updatedTask = await Task.findByIdAndUpdate(id, req.body, { new: true });
    res.status(200).json({ updatedTask, msg: "Task updated successfully" });
  } catch (error) {
    console.log(error);
  }
};

export const deleteTask = async (req, res) => {
  try {
    const id = req.params.id;
    const task = await Task.findById(id);

    if (!task) {
      return res.status(404).json({ msg: "Task not found" });
    }
    await Task.findByIdAndDelete(id);
    res.status(200).json({ msg: "Task deleted successfully" });
  } catch (error) {
    console.log(error);
  }
};